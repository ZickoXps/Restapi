<?php

if ($_SERVER["REQUEST_METHOD"]=="GET")
	{
		require_once 'conexion.php';
		$User=$_GET["User"];
		$Clave=$_GET["Clave"];
		
		$query= "SELECT*FROM USUARIO WHERE User ='".$User."' and Clave = '".$Clave."'";
		
		$result=$mysql->query($query);
		if ($mysql->affected_rows>0)
		{
			
			while ($row=$result->fetch_assoc())
			{
				$array=$row;
			}
				echo json_encode($array);
		}
		else 
		{
			
			
		}
		$result->close();
		$mysql -> close();
	}