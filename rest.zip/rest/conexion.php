<?php
	$mysql=new mysqli("localhost","root","","restapi");
	if ($mysql->connect_error)
	{
		die("Error");
		
		
		
	}else {
		
		//echo "Exito";
	}