<?php
	
	if ($_SERVER["REQUEST_METHOD"]=="POST")
	{
		require_once 'conexion.php';
		
		$User=$_POST["User"];
		$Clave=$_POST["Clave"];
		$Puntos=$_POST["Puntos"];
		$query= "INSERT INTO usuario (User,Clave,Puntos) values ('".$User."','".$Clave."','".$Puntos."')";
		
		$result=$mysql->query($query);
		if ($result==true)
		{
			echo "Exito de registro";
			
		}
		else 
		{
			echo "Error de registro";
			
		}
		$result->close();
		$mysql -> close();
	}