package com.byazbrian.restapi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.TableLayout
import android.widget.TextView
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException

class Lobby2 : AppCompatActivity() {
    var txtuser: EditText?=null
    var txtpuntos: EditText?=null
    var txtcla: EditText?=null
    var tbpremios: TableLayout?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lobby2)
        //Find
        txtuser=findViewById(R.id.txtuser);
        txtpuntos=findViewById(R.id.txtpuntos);
        txtcla=findViewById(R.id.txtcla);
        tbpremios= findViewById(R.id.tbpremios)
        tbpremios?.removeAllViews()

        consult()



        val User:String? = intent.getStringExtra("User").toString()
        val Clave:String? = intent.getStringExtra("Clave").toString()
        val queue=Volley.newRequestQueue(this)
        val url= "http://192.168.56.1/rest/registro.php?User=$User&Clave=$Clave"
        val jsonObjectRequest = JsonObjectRequest(
                Request.Method.GET,url,null, Response.Listener{
            response ->txtuser?.setText(response.getString("User"))
            txtcla?.setText(response.getString("Clave").toString())
            txtpuntos?.setText(response.getInt("Puntos").toString())


                                                                }, { error->Toast.makeText(this,error.toString(),Toast.LENGTH_LONG).show()}
        )
        queue.add(jsonObjectRequest)

    }
    fun clicktable(view: View)
    {
        Toast.makeText(this,view.id.toString(),Toast.LENGTH_LONG).show()
    }
    fun consult()
    {
        var queue = Volley.newRequestQueue(this )
        var url = "http://192.168.56.1/rest/consulta.php"
        var jsonObjectRequest = JsonObjectRequest(
                Request.Method.GET,url,null, Response.Listener{ response ->

            var jsonArray= response.getJSONArray("data")
            for(i in 0 until jsonArray.length()) {
                var jsonObject = jsonArray.getJSONObject(i)
                val registro = LayoutInflater.from(this).inflate(R.layout.tabler_row_np, null, false)
                val colpremios = registro.findViewById<View>(R.id.colpremios) as TextView
                val colpuntos = registro.findViewById<View>(R.id.colpuntos) as TextView
                val colcomprar = registro.findViewById<View>(R.id.colcomprar)
                colpremios.text = jsonObject.getString("Premios")
                colpuntos.text = jsonObject.getString("Puntoscanjear")
                colcomprar.id = i
                tbpremios?.addView(registro)

            }            }
        ,Response.ErrorListener { error-> })
        queue.add(jsonObjectRequest)
}}

